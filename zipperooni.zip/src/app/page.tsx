'use client';

import Image from "next/image";
import Link from 'next/link';
import { useEffect, useState } from 'react';

export default function Home() {
  const [mounted, setMounted] = useState(false);
  const [time, setTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState('home');
  const [activeProjectTab, setActiveProjectTab] = useState('featured');
  const [activeExpTab, setActiveExpTab] = useState('work');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setMounted(true);
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    setTimeout(() => {
      setIsLoading(false);
    }, 100);

    return () => clearInterval(timer);
  }, []);

  if (!mounted) {
    return null;
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const tabs = [
    { id: 'home', label: 'Home' },
    { id: 'projects', label: 'Projects' },
    { id: 'experience', label: 'Experience' }
  ];

  const projectTabs = [
    { id: 'featured', label: 'Featured' },
    { id: 'all', label: 'All Projects' }
  ];

  const expTabs = [
    { id: 'work', label: 'Work' },
    { id: 'research', label: 'Research' }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      <div className={`${isLoading ? 'opacity-0' : 'animate-fade-in'}`}>
        {/* Left Sidebar - Fixed Profile */}
        <aside className="fixed top-1/2 left-12 -translate-y-1/2 w-[450px]">
          <div className="card rounded-3xl p-10 backdrop-blur-lg bg-opacity-10 hover:bg-opacity-20 transition-all">
            <div className="text-center">
              <h1 className="text-5xl font-bold mb-4 gradient-text animate-gradient">Arnav Bhatt</h1>
              <p className="text-gray-400 text-xl">CS @ NCSU. I create cool things using code.</p>
            </div>

            <div className="flex justify-center space-x-8 mt-8">
              <Link href="mailto:ambhatt2@ncsu.edu" className="text-gray-400 hover:text-white transition-all hover:scale-110">
                <span className="sr-only">Email</span>
                <svg className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                  <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                </svg>
              </Link>
              <Link href="https://linkedin.com/in/arnavbhat" className="text-gray-400 hover:text-white transition-all hover:scale-110">
                <span className="sr-only">LinkedIn</span>
                <svg className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
              </Link>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-800">
              <div className="time-card rounded-2xl p-6 text-center">
                <div className="text-4xl font-bold gradient-text">{formatTime(time)}</div>
                <div className="text-gray-400 text-lg mt-2">Raleigh, NC</div>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="ml-[500px] min-h-screen flex flex-col items-center">
          {/* Navigation */}
          <nav className="glass-effect fixed top-12 right-1/2 translate-x-1/2 z-10 rounded-3xl p-6">
            <div className="flex space-x-12">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`nav-item px-10 py-5 rounded-2xl text-2xl font-semibold transition-all hover:scale-105 ${
                    activeTab === tab.id
                      ? 'text-white active bg-[#1a1a1a]'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </nav>

          {/* Content Sections */}
          <div className="w-full min-h-screen flex items-center justify-center p-16">
            {/* About Section */}
            {activeTab === 'home' && (
              <section className="w-[900px] animate-fade-in">
                <div className="card rounded-3xl p-12 backdrop-blur-lg bg-opacity-10 hover:bg-opacity-20 transition-all">
                  <h2 className="text-5xl font-bold mb-10 gradient-text animate-gradient">Who am I?</h2>
                  <p className="text-gray-300 text-2xl leading-relaxed">
                    I'm a Computer Science student at North Carolina State University with a strong foundation in software development.
                    Currently maintaining a GPA of 3.86, I specialize in building efficient and scalable applications using modern technologies.
                  </p>
                </div>
              </section>
            )}

            {/* Projects Section */}
            {activeTab === 'projects' && (
              <section className="w-[1000px] animate-fade-in">
                <div className="space-y-10">
                  <div className="flex justify-between items-center mb-12">
                    <h2 className="text-5xl font-bold gradient-text animate-gradient">Projects</h2>
                    <div className="flex space-x-4 bg-[#1a1a1a] rounded-2xl p-3">
                      {projectTabs.map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setActiveProjectTab(tab.id)}
                          className={`px-8 py-4 rounded-xl text-lg transition-all hover:scale-105 ${
                            activeProjectTab === tab.id
                              ? 'bg-[#2a2a2a] text-white'
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-10">
                    <div className="card rounded-3xl p-12 hover:scale-105 transition-all duration-300 backdrop-blur-lg bg-opacity-10 hover:bg-opacity-20">
                      <h3 className="text-4xl font-semibold">LogStream</h3>
                      <p className="text-gray-400 text-2xl mt-8">A gRPC-based logging service for distributed systems with Protocol Buffer</p>
                      <div className="flex flex-wrap gap-4 mt-10">
                        <span className="tag px-8 py-4 rounded-xl text-lg">Go</span>
                        <span className="tag px-8 py-4 rounded-xl text-lg">gRPC</span>
                        <span className="tag px-8 py-4 rounded-xl text-lg">Protocol Buffer</span>
                      </div>
                    </div>

                    <div className="card rounded-3xl p-12 hover:scale-105 transition-all duration-300 backdrop-blur-lg bg-opacity-10 hover:bg-opacity-20">
                      <h3 className="text-4xl font-semibold">Transit Delay Service</h3>
                      <p className="text-gray-400 text-2xl mt-8">Real-time transit information service for Raleigh's Metro Transit</p>
                      <div className="flex flex-wrap gap-4 mt-10">
                        <span className="tag px-8 py-4 rounded-xl text-lg">Java</span>
                        <span className="tag px-8 py-4 rounded-xl text-lg">Spring Boot</span>
                        <span className="tag px-8 py-4 rounded-xl text-lg">AWS</span>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* Experience Section */}
            {activeTab === 'experience' && (
              <section className="w-[1000px] animate-fade-in">
                <div className="space-y-10">
                  <div className="flex justify-between items-center mb-12">
                    <h2 className="text-5xl font-bold gradient-text animate-gradient">Experience</h2>
                    <div className="flex space-x-4 bg-[#1a1a1a] rounded-2xl p-3">
                      {expTabs.map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setActiveExpTab(tab.id)}
                          className={`px-8 py-4 rounded-xl text-lg transition-all hover:scale-105 ${
                            activeExpTab === tab.id
                              ? 'bg-[#2a2a2a] text-white'
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-10">
                    <div className="card rounded-3xl p-12 hover:scale-105 transition-all duration-300 backdrop-blur-lg bg-opacity-10 hover:bg-opacity-20">
                      <h3 className="text-4xl font-semibold">Amazon</h3>
                      <p className="text-gray-400 text-2xl mt-6">Incoming Software Development Engineer Intern</p>
                      <p className="text-gray-500 text-xl mt-3">May 2025 • Seattle, WA</p>
                    </div>
                    
                    <div className="card rounded-3xl p-12 hover:scale-105 transition-all duration-300 backdrop-blur-lg bg-opacity-10 hover:bg-opacity-20">
                      <h3 className="text-4xl font-semibold">Batista Computing Lab - NC State</h3>
                      <p className="text-gray-400 text-2xl mt-6">Undergraduate Researcher - Embedded ML</p>
                      <p className="text-gray-500 text-xl mt-3">Aug. 2024 - Dec. 2024 • Raleigh, NC</p>
                      <ul className="list-disc list-inside text-gray-400 space-y-5 mt-8 text-2xl">
                        <li>Engineered LOGCAT, a low-overhead intrusion classification model for Controller Area Networks (CAN)</li>
                        <li>Designed autoboot functionality in FreeRTOS to dynamically switch between ARM and RISC-V architectures</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </section>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
