import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Arnav Bhatt - Software Engineer",
  description: "Personal website and portfolio of Arnav Bhatt - Software Engineer",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-gray-900 text-gray-100 min-h-screen`}>
        <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {children}
        </main>
      </body>
    </html>
  );
}
